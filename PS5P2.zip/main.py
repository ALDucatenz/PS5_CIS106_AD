#Display all the numbers from the start value to stop value using the increment value as you proceed.

startv = int(input("Enter a start value: "))
stopv = int(input("Enter a stop value: "))
incrv = int(input("Enter an increment value: "))

while startv <= stopv :
  print(startv)
  startv = startv + incrv