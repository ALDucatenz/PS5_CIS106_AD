counter = 0
total = 0 

response = input("Do you want to compute Gross pay?(Yes or No): ")

while response == "Yes":
  counter = counter + 1
  name = input("Enter Employee's last name: ")
  hours = float(input("Enter Employee's hours worked: "))
  rate = float(input("Enter Emplyee's rate of pay: $"))
 
  if float(hours) > 40:
    bonus = 1.5
  else:
    bonus = 1
 
  pay = float(rate) * bonus
  gross = float(pay) * hours
  total = total + gross
  
  print("Gross pay of",name,"is $",gross)
  
  response = input("Do you want to compute Gross pay? (Yes or No): ")
print("Total number of Employees: ",counter)

avg = total / counter

print("Total Gross pay: $",total)
print("Average Gross pay: $", avg)