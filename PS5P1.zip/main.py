#Display the odd numbers starting at 1 and ending with 25.

startv = 1
stopv = 25
incrv = 2

while startv <= stopv :
  print(startv)
  startv = startv + incrv