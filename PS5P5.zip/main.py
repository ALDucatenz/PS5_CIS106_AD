distot = 0 

response = input("Do you want to compute the Total discount amount? (Yes or No): ")

while response == "Yes" :
 
  quantity = float(input("Enter Quantity: "))
  
  price = float(input("Enter Price: $"))
  
  ext = price * quantity
  if ext > 10000.00 :
    discount = ext * .25
  else :
    discount = ext * .1
  
  distot = distot + discount

  total = ext - discount
  
  print("Extended price: $", ext)
  print("Discount amount: $", discount)
  print("Total amount: $", total)

  response = input("Do you want to compute another Total amount? (Yes or No): ")

print("Total discount amount for each order: $",distot)
